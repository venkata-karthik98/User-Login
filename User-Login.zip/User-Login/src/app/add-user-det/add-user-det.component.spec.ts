import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserDetComponent } from './add-user-det.component';

describe('AddUserDetComponent', () => {
  let component: AddUserDetComponent;
  let fixture: ComponentFixture<AddUserDetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUserDetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserDetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
