import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StorageServiceModule} from 'angular-webstorage-service';
import { HomeComponent } from './home/home.component';
import { CommonHeaderComponent } from './common-header/common-header.component';
import { MaterialModule } from './material-design.module';
import { ViewUserDetComponent } from './view-user-det/view-user-det.component';
import { AddUserDetComponent } from './add-user-det/add-user-det.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    CommonHeaderComponent,
    ViewUserDetComponent,
    AddUserDetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    StorageServiceModule,
    MaterialModule
  ],
  exports: [
    CommonHeaderComponent,
    MaterialModule,
    ViewUserDetComponent,
    AddUserDetComponent
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents:[
    ViewUserDetComponent,
    AddUserDetComponent
  ]
})
export class AppModule { }
