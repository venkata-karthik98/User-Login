import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUserDetComponent } from './view-user-det.component';

describe('ViewUserDetComponent', () => {
  let component: ViewUserDetComponent;
  let fixture: ComponentFixture<ViewUserDetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewUserDetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUserDetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
