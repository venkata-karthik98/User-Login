import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-view-user-det',
  templateUrl: './view-user-det.component.html',
  styleUrls: ['./view-user-det.component.scss']
})
export class ViewUserDetComponent implements OnInit {
  dataUserDetails : any ;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any, 
    private DailogueboxRef: MatDialogRef<ViewUserDetComponent>, 
  ) { }

  ngOnInit(): void {
  }
  Actions(action,Id){
    debugger
    this.dataUserDetails.action = action;
    this.DailogueboxRef.close(this.dataUserDetails);
  }
}
