import { Component, OnInit, ViewChild } from '@angular/core';
import { Input, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import {MatDialog, MatDialogConfig } from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ActivatedRoute, Router} from '@angular/router';
import {MatBottomSheet, MatBottomSheetRef} from '@angular/material/bottom-sheet';
import { Subscription } from 'rxjs';
import { ViewUserDetComponent } from '../view-user-det/view-user-det.component';
import { AddUserDetComponent } from '../add-user-det/add-user-det.component';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  @ViewChild('UserDetailsPaginator', { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  message: string = "test";
  subscription: Subscription;

  PageUserList: any;
  pageTitle = 'User DashBoard';
  displayedColumns = ['UserName', 'UserEmailId', 'Gender','City', 'Actions'];
  ELEMENT_DATA : any [] = [];
  dataSource : any;
  constructor(
    private matDialog: MatDialog, 
    private snackbar : MatSnackBar
  ) { 
    this.ELEMENT_DATA = [
      {ID : '1', USERNAME :'Venkata Karthik',USEREMAIL : 'venkatakarthik1998@gmail.com', GENDER:'Male', CITY:'Nellore'},
      {ID : '2', USERNAME :'Lingeshwar Swamy',USEREMAIL : 'Lingehwarswamy@gmail.com', GENDER:'Male', CITY:'Chennai'},
      { ID : '3', USERNAME :'Anitha Gosetty',USEREMAIL : 'GosettyAnitha@yahoo.com', GENDER:'Female', CITY:'Chennai'},
      {ID : '4', USERNAME :'Venkata Karthik',USEREMAIL : 'karthik98@gmail.com', GENDER:'Male', CITY:'Nellore'},
      { ID : '5',USERNAME :'Swamy',USEREMAIL : 'swamy@gmail.com', GENDER:'Male', CITY:'Chennai'},
      {ID : '6', USERNAME :'Shradha',USEREMAIL : 'Shradha@yahoo.com', GENDER:'Female', CITY:'Punjab'},
      {ID : '7', USERNAME :'Venkat',USEREMAIL : 'venkat1998@gmail.com', GENDER:'Male', CITY:'Delhi'},
      {ID : '8', USERNAME :'Munu Swamy',USEREMAIL : 'Munuswamy@gmail.com', GENDER:'Male', CITY:'Chennai'},
      {ID : '9', USERNAME :'Amala',USEREMAIL : 'Amala@yahoo.com', GENDER:'Female', CITY:'Vizag'}
    ];
  }

  ngOnInit(): void {
    debugger
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngAfterViewInit() {
    
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  ViewUserDetails(UserData): void {
    debugger

   // ObservationData.push({"auditid":this.auditid});
    const dialogRef = this.matDialog.open(ViewUserDetComponent, {
      data: UserData,
      width: '45%'
    });
  }

  addUserDetails(UserData){
    debugger
    let data;
    if(UserData){
      data = UserData
    }
    else{
      data = this.ELEMENT_DATA.length
    }
    // ObservationData.push({"auditid":this.auditid});
     const dialogRef = this.matDialog.open(AddUserDetComponent, {
       data: data,
       width: '20%'
     });
 
     dialogRef.afterClosed().subscribe((response)=>{
       debugger
       
      
      if(UserData){
        this.showUpdatedItem(response)
      }
      else{
        this.ELEMENT_DATA.push(response);
        this.snackbar.open('The user '+ response.USERNAME +' is Successfully Added', 'OK', {
          duration: 5000
        });
       this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
       console.log('added user',response);
      }
     });
  }

  showUpdatedItem(newItem){
    debugger
    let updateItem = this.ELEMENT_DATA.find(this.findIndexToUpdate, newItem.ID);

    let index = this.ELEMENT_DATA.indexOf(updateItem);


    this.ELEMENT_DATA[index] = newItem;
    this.snackbar.open('The user '+ newItem.USERNAME +' is Successfully Updated', 'OK', {
      duration: 5000
    });
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  findIndexToUpdate(newItem) { 
    debugger
        return newItem.ID === this;
  }
}
