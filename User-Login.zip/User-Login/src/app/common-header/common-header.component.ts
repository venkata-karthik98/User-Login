import { Component, OnInit , Inject, OnDestroy} from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { OverlayContainer } from '@angular/cdk/overlay';
import { StorageServiceModule} from 'angular-webstorage-service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-common-header',
  templateUrl: './common-header.component.html',
  styleUrls: ['./common-header.component.scss']
})
export class CommonHeaderComponent implements OnInit {

  isDark = false;
  themeColor: 'no-color' | 'accent' | 'warn' = 'no-color';
  searchword:any;
  message:string;
  username : string;

  constructor(
    @Inject(LOCAL_STORAGE) private storage: WebStorageService,
    private breakpointObserver: BreakpointObserver,
    private overlayContainer: OverlayContainer,
    private activatedRoute : ActivatedRoute,
  private router : Router
  ) { }

   

  ngOnInit(): void {
  this.username = this.storage.get('UserName');
  }


  signOut(): void{
   this.storage.remove('UserName');
   this.router.navigate([''], { relativeTo: this.activatedRoute });
  }


}
