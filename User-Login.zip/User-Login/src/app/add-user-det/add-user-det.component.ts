import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-add-user-det',
  templateUrl: './add-user-det.component.html',
  styleUrls: ['./add-user-det.component.scss']
})
export class AddUserDetComponent implements OnInit {
  userForm: FormGroup;
  Obj : any = [];
  constructor(
   @Inject(MAT_DIALOG_DATA) public data: any, 
    private DailogueboxRef: MatDialogRef<AddUserDetComponent>, 
  ) { }

  ngOnInit(): void {
    debugger
    this.userForm = new FormGroup({
      username : new FormControl('',[Validators.required]),
      email : new FormControl('',[Validators.required,Validators.email]),
      gender : new FormControl('',[Validators.required]),
      city : new FormControl('',[Validators.required])
    })
    
  }
  ngAfterViewInit() {
    
    if(this.data.USERNAME){
      debugger
      this.userForm.get('username').setValue(this.data.USERNAME);
      this.userForm.get('email').setValue(this.data.USEREMAIL);
      this.userForm.get('gender').setValue(this.data.GENDER);
      this.userForm.get('city').setValue(this.data.CITY);
    }

  }

  OnSubmit(){
    let id;
    if(this.data.USERNAME){
     id = this.data.ID
    }
    else{
      id = this.data+1
    }
    this.Obj = {
      "ID" : id,
      "USERNAME" : this.userForm.value.username,
      "USEREMAIL" : this.userForm.value.email,
      "GENDER" : this.userForm.value.gender,
      "CITY" : this.userForm.value.city
    }
    this.DailogueboxRef.close(this.Obj);
  }
  public checkError = (controlName: string, errorName: string) => {
    return this.userForm.controls[controlName].hasError(errorName);
  }
}
